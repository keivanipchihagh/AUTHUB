#include <stdio.h>
int main(){
    printf("jaber babaki");
    return 0;
}